import random

T_Nombre = 1 #Numéro du tirage
Listes_Cotes = [ "PILE !" , "FACE !" ] #Création de la liste "Pile ou Face"
Dictionnaires_Tirages = { "pile" : 0 , "face" : 0 } # Création du dictionnaire "Pile ou Face"

while True : # création d'une boucle

    T_Tirage =  random.choice ( Listes_Cotes )
    if T_Tirage == "PILE !" : Dictionnaires_Tirages [ "pile" ] = Dictionnaires_Tirages [ "pile" ] + 1
    if T_Tirage == "FACE !" : Dictionnaires_Tirages [ "face" ] = Dictionnaires_Tirages [ "face" ] + 1

    print ( f"Pour le tirage numéro { T_Nombre }, c'est { T_Tirage }" )
    print ( "Voici le résultat du tirage ..." )
    print ( Dictionnaires_Tirages )
    print ( )

    tempo = input ( "Souhaitez-vous un autre tirage (N ou n pour arrêter) ? " )
    if tempo.lower ( ) == "n" : break
    T_Nombre += 1
    print ( )

print ( "Au revoir." )


