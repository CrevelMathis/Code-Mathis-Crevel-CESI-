Année_naissance = int(input("Saisir l'année de naissance : "))
Année_actuelle = int(input("Saisir l'année actuelle :"))
Age = Année_naissance-Année_actuelle
print ("Tu as",Age,"ans")

if(Age>=18):
    print("Tu es Majeur !")
else:
    print ("Tu es Mineur !")
