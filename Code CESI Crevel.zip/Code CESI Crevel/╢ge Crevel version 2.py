age = input("Tapez votre âge :")
age = int(age)
if(age>=18):
    print("Vous êtes majeur !")
else:
    print ("Vous êtes mineur !")